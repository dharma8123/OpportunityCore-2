import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  bio: string;
  location: string;
  skills: string[];
  profilePicture: string;
  connections: string[];
  posts: Post[];
  subscriptionPlan: 'basic' | 'premium';
  subscriptionExpiry?: Date;
  linkedinUrl?: string;
  resumeFile?: string;
  jobMatches?: JobMatch[];
  tokens: number;
}

interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  image?: string;
  likes: string[];
  comments: Comment[];
  timestamp: Date;
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: Date;
}

interface JobMatch {
  id: string;
  title: string;
  company: string;
  location: string;
  matchScore: number;
  description: string;
  requirements: string[];
  salary?: string;
  type: 'full-time' | 'part-time' | 'contract' | 'freelance';
  postedDate: Date;
  boosted?: boolean;
}

interface AuthContextType {
  user: User | null;
  allUsers: User[];
  allPosts: Post[];
  jobMatches: JobMatch[];
  login: (email: string, password: string) => boolean;
  signup: (userData: Omit<User, 'id' | 'connections' | 'posts' | 'subscriptionPlan' | 'tokens'>) => boolean;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  uploadProfilePicture: (file: File) => Promise<string>;
  uploadResume: (file: File) => Promise<void>;
  parseResume: (resumeText: string) => string[];
  createPost: (content: string, image?: string) => void;
  likePost: (postId: string) => void;
  addComment: (postId: string, content: string) => void;
  sendConnectionRequest: (userId: string) => void;
  acceptConnection: (userId: string) => void;
  connectMetaMask: () => Promise<string | null>;
  upgradeToPremium: () => Promise<boolean>;
  purchaseTokens: (amount: number) => Promise<boolean>;
  boostProfile: () => Promise<boolean>;
  getAIJobMatches: () => JobMatch[];
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Demo data with enhanced features
const demoUsers: User[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    bio: 'Senior Software Engineer passionate about React and Node.js',
    location: 'Mumbai, India',
    skills: ['React', 'Node.js', 'TypeScript', 'MongoDB'],
    profilePicture: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?w=150',
    connections: ['2'],
    posts: [],
    subscriptionPlan: 'premium',
    subscriptionExpiry: new Date('2024-12-31'),
    linkedinUrl: 'https://linkedin.com/in/sarahjohnson',
    tokens: 50
  },
  {
    id: '2',
    name: 'Rahul Sharma',
    email: 'rahul@example.com',
    bio: 'Product Manager with 5+ years experience in fintech',
    location: 'Bangalore, India',
    skills: ['Product Management', 'Analytics', 'Agile', 'UX Design'],
    profilePicture: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?w=150',
    connections: ['1'],
    posts: [],
    subscriptionPlan: 'basic',
    tokens: 10
  },
  {
    id: '3',
    name: 'Priya Patel',
    email: 'priya@example.com',
    bio: 'Data Scientist specializing in ML and AI solutions',
    location: 'Delhi, India',
    skills: ['Python', 'Machine Learning', 'Data Analysis', 'TensorFlow'],
    profilePicture: 'https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?w=150',
    connections: [],
    posts: [],
    subscriptionPlan: 'basic',
    tokens: 5
  }
];

const demoPosts: Post[] = [
  {
    id: '1',
    userId: '1',
    userName: 'Sarah Johnson',
    userAvatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?w=150',
    content: 'Excited to share that our team just launched a new feature using React 18! The concurrent features are game-changing. 🚀',
    likes: ['2'],
    comments: [
      {
        id: '1',
        userId: '2',
        userName: 'Rahul Sharma',
        content: 'Congratulations! Would love to hear more about your implementation.',
        timestamp: new Date('2024-01-15T10:30:00')
      }
    ],
    timestamp: new Date('2024-01-15T09:00:00')
  },
  {
    id: '2',
    userId: '2',
    userName: 'Rahul Sharma',
    userAvatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?w=150',
    content: 'Just finished reading "Inspired" by Marty Cagan. Highly recommend it to all product managers out there! 📚',
    image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?w=600',
    likes: ['1', '3'],
    comments: [],
    timestamp: new Date('2024-01-14T14:20:00')
  }
];

const demoJobMatches: JobMatch[] = [
  {
    id: '1',
    title: 'Senior React Developer',
    company: 'TechCorp India',
    location: 'Mumbai, India',
    matchScore: 95,
    description: 'We are looking for a Senior React Developer to join our dynamic team.',
    requirements: ['React', 'TypeScript', 'Node.js', '5+ years experience'],
    salary: '₹15-25 LPA',
    type: 'full-time',
    postedDate: new Date('2024-01-10'),
    boosted: true
  },
  {
    id: '2',
    title: 'Product Manager - Fintech',
    company: 'PayNext Solutions',
    location: 'Bangalore, India',
    matchScore: 88,
    description: 'Lead product development for our next-generation payment platform.',
    requirements: ['Product Management', 'Fintech Experience', 'Analytics', 'Agile'],
    salary: '₹20-30 LPA',
    type: 'full-time',
    postedDate: new Date('2024-01-12')
  },
  {
    id: '3',
    title: 'ML Engineer',
    company: 'AI Innovations',
    location: 'Delhi, India',
    matchScore: 92,
    description: 'Build and deploy machine learning models at scale.',
    requirements: ['Python', 'TensorFlow', 'Machine Learning', 'Data Science'],
    salary: '₹18-28 LPA',
    type: 'full-time',
    postedDate: new Date('2024-01-08')
  }
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>(demoUsers);
  const [allPosts, setAllPosts] = useState<Post[]>(demoPosts);
  const [jobMatches] = useState<JobMatch[]>(demoJobMatches);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      // Convert subscriptionExpiry back to Date object if it exists
      if (parsedUser.subscriptionExpiry) {
        parsedUser.subscriptionExpiry = new Date(parsedUser.subscriptionExpiry);
      }
      setUser(parsedUser);
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    const foundUser = allUsers.find(u => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('currentUser', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const signup = (userData: Omit<User, 'id' | 'connections' | 'posts' | 'subscriptionPlan' | 'tokens'>): boolean => {
    const existingUser = allUsers.find(u => u.email === userData.email);
    if (existingUser) {
      return false;
    }

    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      connections: [],
      posts: [],
      subscriptionPlan: 'basic',
      tokens: 10
    };

    setAllUsers(prev => [...prev, newUser]);
    setUser(newUser);
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  const updateProfile = (updates: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);
    setAllUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));
  };

  const uploadProfilePicture = async (file: File): Promise<string> => {
    // Simulate file upload
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const imageUrl = reader.result as string;
        updateProfile({ profilePicture: imageUrl });
        resolve(imageUrl);
      };
      reader.readAsDataURL(file);
    });
  };

  const uploadResume = async (file: File): Promise<void> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const resumeContent = reader.result as string;
        const extractedSkills = parseResume(resumeContent);
        updateProfile({ 
          resumeFile: file.name,
          skills: [...new Set([...user?.skills || [], ...extractedSkills])]
        });
        resolve();
      };
      reader.readAsText(file);
    });
  };

  const parseResume = (resumeText: string): string[] => {
    // Simple skill extraction logic
    const skillKeywords = [
      'React', 'Angular', 'Vue', 'JavaScript', 'TypeScript', 'Node.js', 'Python', 'Java',
      'C++', 'C#', 'PHP', 'Ruby', 'Go', 'Rust', 'Swift', 'Kotlin', 'Flutter', 'React Native',
      'HTML', 'CSS', 'SASS', 'LESS', 'Bootstrap', 'Tailwind', 'Material-UI', 'Chakra UI',
      'MongoDB', 'PostgreSQL', 'MySQL', 'Redis', 'Firebase', 'AWS', 'Azure', 'GCP',
      'Docker', 'Kubernetes', 'Jenkins', 'Git', 'GitHub', 'GitLab', 'Jira', 'Confluence',
      'Machine Learning', 'Data Science', 'AI', 'TensorFlow', 'PyTorch', 'Pandas', 'NumPy',
      'Product Management', 'Agile', 'Scrum', 'UX Design', 'UI Design', 'Figma', 'Sketch'
    ];

    const foundSkills: string[] = [];
    const lowerCaseText = resumeText.toLowerCase();

    skillKeywords.forEach(skill => {
      if (lowerCaseText.includes(skill.toLowerCase())) {
        foundSkills.push(skill);
      }
    });

    return foundSkills;
  };

  const createPost = (content: string, image?: string) => {
    if (!user) return;

    const newPost: Post = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      userAvatar: user.profilePicture,
      content,
      image,
      likes: [],
      comments: [],
      timestamp: new Date()
    };

    setAllPosts(prev => [newPost, ...prev]);
  };

  const likePost = (postId: string) => {
    if (!user) return;

    setAllPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const hasLiked = post.likes.includes(user.id);
        return {
          ...post,
          likes: hasLiked 
            ? post.likes.filter(id => id !== user.id)
            : [...post.likes, user.id]
        };
      }
      return post;
    }));
  };

  const addComment = (postId: string, content: string) => {
    if (!user) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      content,
      timestamp: new Date()
    };

    setAllPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  const sendConnectionRequest = (userId: string) => {
    if (!user) return;
    console.log(`Connection request sent to user ${userId}`);
  };

  const acceptConnection = (userId: string) => {
    if (!user) return;

    const updatedUser = {
      ...user,
      connections: [...user.connections, userId]
    };

    setUser(updatedUser);
    setAllUsers(prev => prev.map(u => {
      if (u.id === user.id) {
        return updatedUser;
      }
      if (u.id === userId) {
        return {
          ...u,
          connections: [...u.connections, user.id]
        };
      }
      return u;
    }));
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));
  };

  const connectMetaMask = async (): Promise<string | null> => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        return accounts[0];
      } catch (error) {
        console.error('MetaMask connection failed:', error);
        return null;
      }
    } else {
      alert('MetaMask is not installed. Please install MetaMask to continue.');
      return null;
    }
  };

  const upgradeToPremium = async (): Promise<boolean> => {
    if (!user) return false;
    
    // Simulate payment processing
    return new Promise((resolve) => {
      setTimeout(() => {
        const expiryDate = new Date();
        expiryDate.setMonth(expiryDate.getMonth() + 1);
        
        updateProfile({ 
          subscriptionPlan: 'premium',
          subscriptionExpiry: expiryDate,
          tokens: user.tokens + 100
        });
        resolve(true);
      }, 2000);
    });
  };

  const purchaseTokens = async (amount: number): Promise<boolean> => {
    if (!user) return false;
    
    return new Promise((resolve) => {
      setTimeout(() => {
        updateProfile({ tokens: user.tokens + amount });
        resolve(true);
      }, 1500);
    });
  };

  const boostProfile = async (): Promise<boolean> => {
    if (!user || user.tokens < 10) return false;
    
    return new Promise((resolve) => {
      setTimeout(() => {
        updateProfile({ tokens: user.tokens - 10 });
        resolve(true);
      }, 1000);
    });
  };

  const getAIJobMatches = (): JobMatch[] => {
    if (!user) return [];
    
    // AI-powered job matching based on user skills
    return jobMatches
      .map(job => ({
        ...job,
        matchScore: calculateMatchScore(user.skills, job.requirements)
      }))
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, user.subscriptionPlan === 'premium' ? 20 : 5);
  };

  const calculateMatchScore = (userSkills: string[], jobRequirements: string[]): number => {
    const matchingSkills = userSkills.filter(skill => 
      jobRequirements.some(req => req.toLowerCase().includes(skill.toLowerCase()))
    );
    return Math.round((matchingSkills.length / jobRequirements.length) * 100);
  };

  return (
    <AuthContext.Provider value={{
      user,
      allUsers,
      allPosts,
      jobMatches,
      login,
      signup,
      logout,
      updateProfile,
      uploadProfilePicture,
      uploadResume,
      parseResume,
      createPost,
      likePost,
      addComment,
      sendConnectionRequest,
      acceptConnection,
      connectMetaMask,
      upgradeToPremium,
      purchaseTokens,
      boostProfile,
      getAIJobMatches
    }}>
      {children}
    </AuthContext.Provider>
  );
}