import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { CreditCard, Wallet, IndianRupee, CheckCircle, Smartphone, AlertCircle } from 'lucide-react';

export function PaymentPage() {
  const { user, connectMetaMask } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'metamask'>('upi');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');

  const handleMetaMaskConnect = async () => {
    const address = await connectMetaMask();
    if (address) {
      setWalletConnected(true);
      setWalletAddress(address);
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;

    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      alert(`Payment of ₹${amount} processed successfully via ${paymentMethod.toUpperCase()}!`);
      setAmount('');
      setDescription('');
    }, 2000);
  };

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Payment Center</h1>
        <p className="text-gray-600">Secure payments in Indian Rupees</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Payment Form */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Make a Payment</h2>

          <form onSubmit={handlePayment} className="space-y-6">
            {/* Payment Method Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">Payment Method</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-4 border-2 rounded-lg transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Smartphone className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-sm font-medium">UPI</div>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('metamask')}
                  className={`p-4 border-2 rounded-lg transition-all ${
                    paymentMethod === 'metamask'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Wallet className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-sm font-medium">MetaMask</div>
                </button>
              </div>
            </div>

            {/* Amount */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Amount</label>
              <div className="relative">
                <IndianRupee className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What is this payment for?"
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                required
              />
            </div>

            {/* MetaMask Connection */}
            {paymentMethod === 'metamask' && !walletConnected && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 mr-2" />
                  <p className="text-sm font-medium text-orange-800">MetaMask not connected</p>
                </div>
                <button
                  type="button"
                  onClick={handleMetaMaskConnect}
                  className="bg-orange-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-orange-700 transition-colors"
                >
                  Connect MetaMask
                </button>
              </div>
            )}

            {/* Wallet Connected Status */}
            {paymentMethod === 'metamask' && walletConnected && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                  <p className="text-sm font-medium text-green-800">MetaMask Connected</p>
                </div>
                <p className="text-sm text-green-700">Wallet: {walletAddress}</p>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isProcessing || (paymentMethod === 'metamask' && !walletConnected)}
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-2"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <CreditCard className="w-4 h-4" />
                  <span>Pay ₹{amount || '0'}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Payment Info */}
        <div className="space-y-6">
          {/* UPI Details */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">UPI Payment Details</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-600">UPI ID</label>
                <p className="text-gray-900 font-mono">9581575761-2@ybl</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Payment Details Email</label>
                <p className="text-gray-900">sastasridharma@gmail.com</p>
              </div>
            </div>
          </div>

          {/* MetaMask Details */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">MetaMask Wallet</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-600">Wallet Address</label>
                <p className="text-gray-900 font-mono text-sm break-all">
                  0xA3E9564cFaCe9eF22d4a7ceF98896D413b3421CE
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Network</label>
                <p className="text-gray-900">Ethereum Mainnet</p>
              </div>
            </div>
          </div>

          {/* Security Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-medium text-blue-900 mb-2">🔒 Security Notice</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• All payments are processed securely</li>
              <li>• Payment details are sent to the specified email</li>
              <li>• MetaMask payments use blockchain technology</li>
              <li>• Keep your transaction records safe</li>
            </ul>
          </div>

          {/* Payment History */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Transactions</h3>
            <div className="text-center py-8">
              <CreditCard className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">No transactions yet</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}