import React, { useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Edit, MapPin, Briefcase, Award, Plus, X, Upload, Camera, ExternalLink, Star, Zap } from 'lucide-react';

export function ProfilePage() {
  const { user, updateProfile, uploadProfilePicture, uploadResume } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    location: user?.location || '',
    skills: user?.skills?.join(', ') || '',
    linkedinUrl: user?.linkedinUrl || ''
  });
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const resumeInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    const skillsArray = editForm.skills.split(',').map(s => s.trim()).filter(s => s);
    updateProfile({
      name: editForm.name,
      bio: editForm.bio,
      location: editForm.location,
      skills: skillsArray,
      linkedinUrl: editForm.linkedinUrl
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm({
      name: user?.name || '',
      bio: user?.bio || '',
      location: user?.location || '',
      skills: user?.skills?.join(', ') || '',
      linkedinUrl: user?.linkedinUrl || ''
    });
    setIsEditing(false);
  };

  const handleProfilePictureUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsUploading(true);
      try {
        await uploadProfilePicture(file);
      } catch (error) {
        console.error('Upload failed:', error);
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleResumeUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsUploading(true);
      try {
        await uploadResume(file);
        alert('Resume uploaded and skills extracted successfully!');
      } catch (error) {
        console.error('Resume upload failed:', error);
      } finally {
        setIsUploading(false);
      }
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Profile Header */}
        <div className="bg-gradient-to-r from-blue-500 to-green-500 h-48 relative">
          {/* Subscription Badge */}
          <div className="absolute top-6 left-6">
            <div className={`flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              user.subscriptionPlan === 'premium' 
                ? 'bg-yellow-400 text-yellow-900' 
                : 'bg-gray-200 text-gray-700'
            }`}>
              {user.subscriptionPlan === 'premium' ? (
                <>
                  <Star className="w-4 h-4 mr-1" />
                  Premium
                </>
              ) : (
                'Basic'
              )}
            </div>
          </div>

          {/* Tokens Display */}
          <div className="absolute top-6 left-32">
            <div className="flex items-center bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-white">
              <Zap className="w-4 h-4 mr-1" />
              {user.tokens} Tokens
            </div>
          </div>

          {/* Profile Picture */}
          <div className="absolute -bottom-16 left-8">
            <div className="relative">
              <img
                src={user.profilePicture}
                alt={user.name}
                className="w-32 h-32 rounded-full border-4 border-white object-cover shadow-lg"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="absolute bottom-2 right-2 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <Camera className="w-4 h-4" />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleProfilePictureUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="absolute top-6 right-6">
            {isEditing ? (
              <div className="flex space-x-2">
                <button
                  onClick={handleSave}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors"
                >
                  Save
                </button>
                <button
                  onClick={handleCancel}
                  className="bg-gray-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="bg-white text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors flex items-center space-x-2"
              >
                <Edit className="w-4 h-4" />
                <span>Edit Profile</span>
              </button>
            )}
          </div>
        </div>

        {/* Profile Content */}
        <div className="pt-20 p-8">
          {/* Basic Info */}
          <div className="mb-8">
            {isEditing ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
                  <textarea
                    value={editForm.bio}
                    onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                  <input
                    type="text"
                    value={editForm.location}
                    onChange={(e) => setEditForm(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">LinkedIn URL</label>
                  <input
                    type="url"
                    value={editForm.linkedinUrl}
                    onChange={(e) => setEditForm(prev => ({ ...prev, linkedinUrl: e.target.value }))}
                    placeholder="https://linkedin.com/in/yourprofile"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Skills (comma-separated)</label>
                  <input
                    type="text"
                    value={editForm.skills}
                    onChange={(e) => setEditForm(prev => ({ ...prev, skills: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            ) : (
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{user.name}</h1>
                <p className="text-lg text-gray-600 mb-4">{user.bio}</p>
                <div className="flex items-center text-gray-500 mb-2">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span>{user.location || 'Location not specified'}</span>
                </div>
                <div className="flex items-center text-gray-500 mb-2">
                  <Briefcase className="w-4 h-4 mr-2" />
                  <span>{user.connections.length} connections</span>
                </div>
                {user.linkedinUrl && (
                  <div className="flex items-center text-blue-600 hover:text-blue-700">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    <a href={user.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-sm">
                      LinkedIn Profile
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Resume Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Resume</h2>
              <button
                onClick={() => resumeInputRef.current?.click()}
                disabled={isUploading}
                className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <Upload className="w-4 h-4" />
                <span>{isUploading ? 'Uploading...' : 'Upload Resume'}</span>
              </button>
              <input
                ref={resumeInputRef}
                type="file"
                accept=".pdf,.doc,.docx,.txt"
                onChange={handleResumeUpload}
                className="hidden"
              />
            </div>
            {user.resumeFile ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 font-medium">✓ Resume uploaded: {user.resumeFile}</p>
                <p className="text-green-600 text-sm mt-1">Skills have been automatically extracted and added to your profile.</p>
              </div>
            ) : (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <p className="text-gray-600">No resume uploaded yet. Upload your resume to auto-extract skills!</p>
              </div>
            )}
          </div>

          {/* Skills Section */}
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <Award className="w-5 h-5 text-blue-600 mr-2" />
              <h2 className="text-xl font-semibold text-gray-900">Skills</h2>
            </div>
            {user.skills.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {user.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No skills added yet</p>
            )}
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-6 text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">{user.connections.length}</div>
              <div className="text-gray-600">Connections</div>
            </div>
            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-6 text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">{user.posts?.length || 0}</div>
              <div className="text-gray-600">Posts</div>
            </div>
            <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-6 text-center">
              <div className="text-2xl font-bold text-orange-600 mb-1">{user.skills.length}</div>
              <div className="text-gray-600">Skills</div>
            </div>
            <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-6 text-center">
              <div className="text-2xl font-bold text-purple-600 mb-1">{user.tokens}</div>
              <div className="text-gray-600">Tokens</div>
            </div>
          </div>

          {/* Subscription Info */}
          <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-yellow-800 mb-2">
              {user.subscriptionPlan === 'premium' ? 'Premium Subscription' : 'Basic Plan'}
            </h3>
            {user.subscriptionPlan === 'premium' ? (
              <div className="text-yellow-700">
                <p>✓ Unlimited AI job matches</p>
                <p>✓ Resume scoring</p>
                <p>✓ 5 featured applications per month</p>
                <p>✓ Priority support</p>
                {user.subscriptionExpiry && (
                  <p className="mt-2 text-sm">Expires: {user.subscriptionExpiry.toLocaleDateString()}</p>
                )}
              </div>
            ) : (
              <div className="text-yellow-700">
                <p>• Basic job search</p>
                <p>• Limited AI matches (5 per month)</p>
                <p>• Standard resume parsing</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}