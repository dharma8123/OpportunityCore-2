import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { UserPlus, Users, MapPin, Award } from 'lucide-react';

export function ConnectionsPage() {
  const { user, allUsers, sendConnectionRequest, acceptConnection } = useAuth();

  if (!user) return null;

  const connections = allUsers.filter(u => user.connections.includes(u.id));
  const nonConnections = allUsers.filter(u => u.id !== user.id && !user.connections.includes(u.id));

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Network</h1>
        <p className="text-gray-600">Connect with professionals in your field</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <Users className="w-8 h-8 text-blue-600 mr-3" />
            <div>
              <div className="text-2xl font-bold text-gray-900">{connections.length}</div>
              <div className="text-gray-600">Connections</div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <UserPlus className="w-8 h-8 text-green-600 mr-3" />
            <div>
              <div className="text-2xl font-bold text-gray-900">{nonConnections.length}</div>
              <div className="text-gray-600">Suggestions</div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <Award className="w-8 h-8 text-orange-600 mr-3" />
            <div>
              <div className="text-2xl font-bold text-gray-900">0</div>
              <div className="text-gray-600">Pending</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Your Connections */}
        <div>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Connections</h2>
          <div className="space-y-4">
            {connections.length > 0 ? (
              connections.map((connection) => (
                <div key={connection.id} className="bg-white rounded-lg border border-gray-200 p-6">
                  <div className="flex items-start space-x-4">
                    <img
                      src={connection.profilePicture}
                      alt={connection.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900">{connection.name}</h3>
                      <p className="text-gray-600 text-sm mb-2">{connection.bio}</p>
                      <div className="flex items-center text-gray-500 text-sm mb-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span>{connection.location}</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {connection.skills.slice(0, 3).map((skill, index) => (
                          <span
                            key={index}
                            className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                        {connection.skills.length > 3 && (
                          <span className="text-gray-500 text-xs">+{connection.skills.length - 3} more</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-gray-50 rounded-lg p-8 text-center">
                <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No connections yet</h3>
                <p className="text-gray-500">Start connecting with professionals to grow your network!</p>
              </div>
            )}
          </div>
        </div>

        {/* Connection Suggestions */}
        <div>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">People You May Know</h2>
          <div className="space-y-4">
            {nonConnections.map((suggestedUser) => (
              <div key={suggestedUser.id} className="bg-white rounded-lg border border-gray-200 p-6">
                <div className="flex items-start space-x-4">
                  <img
                    src={suggestedUser.profilePicture}
                    alt={suggestedUser.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900">{suggestedUser.name}</h3>
                    <p className="text-gray-600 text-sm mb-2">{suggestedUser.bio}</p>
                    <div className="flex items-center text-gray-500 text-sm mb-3">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>{suggestedUser.location}</span>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {suggestedUser.skills.slice(0, 3).map((skill, index) => (
                        <span
                          key={index}
                          className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                      {suggestedUser.skills.length > 3 && (
                        <span className="text-gray-500 text-xs">+{suggestedUser.skills.length - 3} more</span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        sendConnectionRequest(suggestedUser.id);
                        acceptConnection(suggestedUser.id);
                      }}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Connect</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}