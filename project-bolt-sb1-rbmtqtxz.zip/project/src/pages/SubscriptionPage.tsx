import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Check, Star, Zap, CreditCard, Wallet } from 'lucide-react';

export function SubscriptionPage() {
  const { user, upgradeToPremium, purchaseTokens, connectMetaMask } = useAuth();
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedTokenPackage, setSelectedTokenPackage] = useState<number | null>(null);

  const handleUpgradeToPremium = async () => {
    setIsProcessing(true);
    try {
      const success = await upgradeToPremium();
      if (success) {
        alert('Successfully upgraded to Premium! Welcome to OpportunityCore Premium!');
      }
    } catch (error) {
      console.error('Upgrade failed:', error);
      alert('Upgrade failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePurchaseTokens = async (amount: number) => {
    setIsProcessing(true);
    try {
      const success = await purchaseTokens(amount);
      if (success) {
        alert(`Successfully purchased ${amount} tokens!`);
        setSelectedTokenPackage(null);
      }
    } catch (error) {
      console.error('Token purchase failed:', error);
      alert('Token purchase failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const tokenPackages = [
    { tokens: 50, price: 100, bonus: 0 },
    { tokens: 120, price: 200, bonus: 20 },
    { tokens: 300, price: 500, bonus: 100 },
  ];

  if (!user) return null;

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
        <p className="text-xl text-gray-600">Unlock premium features and boost your career opportunities</p>
      </div>

      {/* Current Plan Status */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Current Plan</h3>
            <div className="flex items-center mt-2">
              {user.subscriptionPlan === 'premium' ? (
                <>
                  <Star className="w-5 h-5 text-yellow-500 mr-2" />
                  <span className="text-yellow-600 font-medium">Premium</span>
                  {user.subscriptionExpiry && (
                    <span className="text-gray-500 ml-2">
                      (Expires: {user.subscriptionExpiry.toLocaleDateString()})
                    </span>
                  )}
                </>
              ) : (
                <>
                  <div className="w-5 h-5 bg-gray-300 rounded mr-2"></div>
                  <span className="text-gray-600 font-medium">Basic</span>
                </>
              )}
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center text-purple-600">
              <Zap className="w-5 h-5 mr-1" />
              <span className="font-semibold">{user.tokens} Tokens</span>
            </div>
          </div>
        </div>
      </div>

      {/* Subscription Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Basic Plan */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Basic</h3>
            <div className="text-3xl font-bold text-gray-900">Free</div>
            <p className="text-gray-600 mt-2">Perfect for getting started</p>
          </div>
          
          <ul className="space-y-3 mb-8">
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Basic job search</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Resume parsing</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>5 AI job matches per month</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Basic networking features</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>10 tokens included</span>
            </li>
          </ul>

          <button
            disabled={user.subscriptionPlan === 'basic'}
            className="w-full bg-gray-100 text-gray-500 py-3 rounded-lg font-medium cursor-not-allowed"
          >
            Current Plan
          </button>
        </div>

        {/* Premium Plan */}
        <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl shadow-lg border-2 border-blue-200 p-8 relative">
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
            <span className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-4 py-1 rounded-full text-sm font-medium">
              Most Popular
            </span>
          </div>
          
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Premium</h3>
            <div className="text-3xl font-bold text-gray-900">₹150<span className="text-lg text-gray-600">/month</span></div>
            <p className="text-gray-600 mt-2">For serious professionals</p>
          </div>
          
          <ul className="space-y-3 mb-8">
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Everything in Basic</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Unlimited AI job matches</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Advanced resume scoring</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>5 featured applications/month</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Priority customer support</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>100 bonus tokens</span>
            </li>
            <li className="flex items-center">
              <Check className="w-5 h-5 text-green-500 mr-3" />
              <span>Advanced analytics</span>
            </li>
          </ul>

          <button
            onClick={handleUpgradeToPremium}
            disabled={isProcessing || user.subscriptionPlan === 'premium'}
            className="w-full bg-gradient-to-r from-blue-600 to-green-600 text-white py-3 rounded-lg font-medium hover:from-blue-700 hover:to-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? 'Processing...' : 
             user.subscriptionPlan === 'premium' ? 'Current Plan' : 'Upgrade to Premium'}
          </button>
        </div>
      </div>

      {/* Token Packages */}
      <div className="mb-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Boost Your Visibility</h2>
          <p className="text-xl text-gray-600">Purchase tokens to boost your profile and job applications</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {tokenPackages.map((pkg, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl shadow-sm border-2 p-6 cursor-pointer transition-all ${
                selectedTokenPackage === index
                  ? 'border-purple-500 bg-purple-50'
                  : 'border-gray-200 hover:border-purple-300'
              }`}
              onClick={() => setSelectedTokenPackage(index)}
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600 mb-2">
                  {pkg.tokens + pkg.bonus} Tokens
                </div>
                {pkg.bonus > 0 && (
                  <div className="text-sm text-green-600 font-medium mb-2">
                    +{pkg.bonus} Bonus Tokens!
                  </div>
                )}
                <div className="text-xl font-bold text-gray-900 mb-4">₹{pkg.price}</div>
                <div className="text-sm text-gray-600 mb-4">
                  ₹{(pkg.price / (pkg.tokens + pkg.bonus)).toFixed(2)} per token
                </div>
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePurchaseTokens(pkg.tokens + pkg.bonus);
                  }}
                  disabled={isProcessing}
                  className="w-full bg-purple-600 text-white py-2 rounded-lg font-medium hover:bg-purple-700 transition-colors disabled:opacity-50"
                >
                  {isProcessing ? 'Processing...' : 'Purchase'}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 text-center text-gray-600">
          <p className="text-sm">Use tokens to:</p>
          <div className="flex justify-center space-x-6 mt-2 text-sm">
            <span>• Boost profile visibility (10 tokens)</span>
            <span>• Feature job applications (5 tokens)</span>
            <span>• Priority in search results (3 tokens)</span>
          </div>
        </div>
      </div>

      {/* Payment Methods */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Payment Methods</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <CreditCard className="w-6 h-6 text-blue-600 mr-3" />
              <h4 className="font-medium text-gray-900">UPI Payment</h4>
            </div>
            <p className="text-gray-600 text-sm mb-3">Pay securely using UPI</p>
            <div className="text-sm text-gray-500">
              <p>UPI ID: 9581575761-2@ybl</p>
              <p>Payment details sent to: sastasridharma@gmail.com</p>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <Wallet className="w-6 h-6 text-purple-600 mr-3" />
              <h4 className="font-medium text-gray-900">Crypto Payment</h4>
            </div>
            <p className="text-gray-600 text-sm mb-3">Pay with MetaMask or Phantom wallet</p>
            <div className="text-sm text-gray-500">
              <p>Wallet: 0xA3E9564cFaCe9eF22d4a7ceF98896D413b3421CE</p>
              <p>Network: Ethereum Mainnet</p>
            </div>
          </div>
        </div>

        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-2">🔒 Secure Payments</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• All payments are processed securely</li>
            <li>• Payment confirmations sent via email</li>
            <li>• Blockchain payments for transparency</li>
            <li>• 30-day money-back guarantee</li>
          </ul>
        </div>
      </div>
    </div>
  );
}