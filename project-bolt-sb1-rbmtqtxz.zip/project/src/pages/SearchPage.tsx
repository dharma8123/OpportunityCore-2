import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Search, MapPin, UserPlus, Filter } from 'lucide-react';

export function SearchPage() {
  const { user, allUsers, sendConnectionRequest, acceptConnection } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'skills' | 'location'>('all');

  if (!user) return null;

  const filteredUsers = allUsers.filter(u => {
    if (u.id === user.id) return false;
    
    const searchLower = searchTerm.toLowerCase();
    
    switch (filterType) {
      case 'skills':
        return u.skills.some(skill => skill.toLowerCase().includes(searchLower));
      case 'location':
        return u.location.toLowerCase().includes(searchLower);
      default:
        return (
          u.name.toLowerCase().includes(searchLower) ||
          u.bio.toLowerCase().includes(searchLower) ||
          u.skills.some(skill => skill.toLowerCase().includes(searchLower)) ||
          u.location.toLowerCase().includes(searchLower)
        );
    }
  });

  const isConnected = (userId: string) => user.connections.includes(userId);

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Search Professionals</h1>
        <p className="text-gray-600">Find and connect with professionals in your industry</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by name, skills, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="pl-10 pr-8 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
            >
              <option value="all">All Fields</option>
              <option value="skills">Skills Only</option>
              <option value="location">Location Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* Search Results */}
      <div className="space-y-6">
        {filteredUsers.length > 0 ? (
          filteredUsers.map((foundUser) => (
            <div key={foundUser.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start space-x-6">
                <img
                  src={foundUser.profilePicture}
                  alt={foundUser.name}
                  className="w-20 h-20 rounded-full object-cover flex-shrink-0"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">{foundUser.name}</h3>
                      <p className="text-gray-600 mb-3">{foundUser.bio}</p>
                      <div className="flex items-center text-gray-500 text-sm mb-4">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span>{foundUser.location}</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {foundUser.skills.map((skill, index) => (
                          <span
                            key={index}
                            className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex-shrink-0">
                      {isConnected(foundUser.id) ? (
                        <div className="bg-green-100 text-green-800 px-4 py-2 rounded-lg font-medium">
                          Connected
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            sendConnectionRequest(foundUser.id);
                            acceptConnection(foundUser.id);
                          }}
                          className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
                        >
                          <UserPlus className="w-4 h-4" />
                          <span>Connect</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-gray-50 rounded-2xl p-12 text-center">
            <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm ? 'No results found' : 'Start searching'}
            </h3>
            <p className="text-gray-500">
              {searchTerm 
                ? `No professionals found matching "${searchTerm}"`
                : 'Enter a search term to find professionals in your network'
              }
            </p>
          </div>
        )}
      </div>

      {/* Search Tips */}
      {!searchTerm && (
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-900 mb-2">Search Tips</h3>
          <ul className="text-blue-800 space-y-1">
            <li>• Search by name to find specific people</li>
            <li>• Use skills filter to find experts in specific technologies</li>
            <li>• Filter by location to find local professionals</li>
            <li>• Try keywords like "React", "Data Science", or "Product Manager"</li>
          </ul>
        </div>
      )}
    </div>
  );
}