import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Heart, MessageCircle, Send, Image, Camera } from 'lucide-react';

export function HomePage() {
  const { user, allPosts, createPost, likePost, addComment } = useAuth();
  const [newPost, setNewPost] = useState('');
  const [newComment, setNewComment] = useState<{[key: string]: string}>({});

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPost.trim()) {
      createPost(newPost);
      setNewPost('');
    }
  };

  const handleAddComment = (postId: string) => {
    const comment = newComment[postId];
    if (comment?.trim()) {
      addComment(postId, comment);
      setNewComment(prev => ({ ...prev, [postId]: '' }));
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  return (
    <div className="max-w-2xl mx-auto py-8 px-4">
      {/* Welcome Message */}
      <div className="bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-2xl p-6 mb-8">
        <h2 className="text-2xl font-bold mb-2">Welcome back, {user?.name}! 👋</h2>
        <p className="text-blue-100">Ready to connect and share your professional journey?</p>
      </div>

      {/* Create Post */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-8">
        <form onSubmit={handleCreatePost}>
          <div className="flex items-start space-x-4">
            <img
              src={user?.profilePicture}
              alt={user?.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div className="flex-1">
              <textarea
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                placeholder="Share something with your network..."
                className="w-full border-0 resize-none focus:ring-0 placeholder-gray-500 text-lg"
                rows={3}
              />
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    className="flex items-center text-gray-500 hover:text-blue-600 transition-colors"
                  >
                    <Image className="w-5 h-5 mr-2" />
                    Photo
                  </button>
                  <button
                    type="button"
                    className="flex items-center text-gray-500 hover:text-blue-600 transition-colors"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Video
                  </button>
                </div>
                <button
                  type="submit"
                  disabled={!newPost.trim()}
                  className="bg-blue-600 text-white px-6 py-2 rounded-full font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  Post
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>

      {/* Posts Feed */}
      <div className="space-y-6">
        {allPosts.map((post) => (
          <div key={post.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            {/* Post Header */}
            <div className="p-6 pb-4">
              <div className="flex items-center space-x-3">
                <img
                  src={post.userAvatar}
                  alt={post.userName}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{post.userName}</h3>
                  <p className="text-sm text-gray-500">{formatTimeAgo(post.timestamp)}</p>
                </div>
              </div>
            </div>

            {/* Post Content */}
            <div className="px-6 pb-4">
              <p className="text-gray-800 leading-relaxed">{post.content}</p>
            </div>

            {/* Post Image */}
            {post.image && (
              <div className="px-6 pb-4">
                <img
                  src={post.image}
                  alt="Post content"
                  className="w-full rounded-lg object-cover max-h-96"
                />
              </div>
            )}

            {/* Post Actions */}
            <div className="px-6 py-4 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <button
                    onClick={() => likePost(post.id)}
                    className={`flex items-center space-x-2 transition-colors ${
                      post.likes.includes(user?.id || '')
                        ? 'text-red-500'
                        : 'text-gray-500 hover:text-red-500'
                    }`}
                  >
                    <Heart
                      className={`w-5 h-5 ${
                        post.likes.includes(user?.id || '') ? 'fill-current' : ''
                      }`}
                    />
                    <span className="text-sm font-medium">{post.likes.length}</span>
                  </button>
                  <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500 transition-colors">
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm font-medium">{post.comments.length}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Comments */}
            {post.comments.length > 0 && (
              <div className="px-6 pb-4 space-y-3">
                {post.comments.map((comment) => (
                  <div key={comment.id} className="flex space-x-3">
                    <div className="w-8 h-8 bg-gray-200 rounded-full flex-shrink-0"></div>
                    <div className="flex-1">
                      <div className="bg-gray-50 rounded-lg px-3 py-2">
                        <p className="text-sm font-medium text-gray-900">{comment.userName}</p>
                        <p className="text-sm text-gray-700">{comment.content}</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{formatTimeAgo(comment.timestamp)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Add Comment */}
            <div className="px-6 pb-6">
              <div className="flex space-x-3">
                <img
                  src={user?.profilePicture}
                  alt={user?.name}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div className="flex-1">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={newComment[post.id] || ''}
                      onChange={(e) => setNewComment(prev => ({ ...prev, [post.id]: e.target.value }))}
                      placeholder="Write a comment..."
                      className="flex-1 border border-gray-300 rounded-full px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleAddComment(post.id);
                        }
                      }}
                    />
                    <button
                      onClick={() => handleAddComment(post.id)}
                      disabled={!newComment[post.id]?.trim()}
                      className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {allPosts.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <MessageCircle className="w-16 h-16 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No posts yet</h3>
          <p className="text-gray-500">Be the first to share something with your network!</p>
        </div>
      )}
    </div>
  );
}