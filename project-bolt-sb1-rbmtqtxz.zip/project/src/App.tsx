import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Navbar } from './components/Navbar';
import { LoginPage } from './pages/LoginPage';
import { SignUpPage } from './pages/SignUpPage';
import { HomePage } from './pages/HomePage';
import { ProfilePage } from './pages/ProfilePage';
import { ConnectionsPage } from './pages/ConnectionsPage';
import { SearchPage } from './pages/SearchPage';
import { PaymentPage } from './pages/PaymentPage';
import { JobsPage } from './pages/JobsPage';
import { SubscriptionPage } from './pages/SubscriptionPage';

type Page = 'login' | 'signup' | 'home' | 'profile' | 'connections' | 'search' | 'payment' | 'jobs' | 'subscription';

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('login');

  useEffect(() => {
    if (!user && currentPage !== 'signup') {
      setCurrentPage('login');
    } else if (user && (currentPage === 'login' || currentPage === 'signup')) {
      setCurrentPage('home');
    }
  }, [user, currentPage]);

  if (!user && currentPage !== 'signup') {
    return currentPage === 'login' ? 
      <LoginPage onSignUp={() => setCurrentPage('signup')} /> :
      <SignUpPage onLogin={() => setCurrentPage('login')} />;
  }

  if (currentPage === 'signup') {
    return <SignUpPage onLogin={() => setCurrentPage('login')} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="pt-16">
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'profile' && <ProfilePage />}
        {currentPage === 'connections' && <ConnectionsPage />}
        {currentPage === 'search' && <SearchPage />}
        {currentPage === 'payment' && <PaymentPage />}
        {currentPage === 'jobs' && <JobsPage />}
        {currentPage === 'subscription' && <SubscriptionPage />}
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;